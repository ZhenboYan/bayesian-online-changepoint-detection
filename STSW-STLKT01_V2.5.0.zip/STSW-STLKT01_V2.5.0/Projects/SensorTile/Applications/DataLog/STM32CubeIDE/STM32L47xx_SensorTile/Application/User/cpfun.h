///*
// * test.hpp
// *
// *  Created on: May 6, 2022
// *      Author: user
// */
//
//#ifndef APPLICATION_USER_TEST_H_
//#define APPLICATION_USER_TEST_H_
//
//#ifdef __cplusplus
//extern "C" {
//#endif
//
//#include <iostream>
//#include <vector>
//#include <cmath>
//
//int stupid(int x);
//
//void printvec(std::vector<float> v);
//
//std::vector<float> ele_mul3(const std::vector<float> &v1,const std::vector<float> &v2,const std::vector<float> &v3);
//
//float sum_ele_mul3(const std::vector<float> &v1,const std::vector<float> &v2,const std::vector<float> &v3);
//
//std::vector<float> all_mul(const std::vector<float> &v1, const float &num);
//
//std::vector<float> all_div(const std::vector<float> &v1, const float &num);
//
//std::vector<float> sub_all(const std::vector<float> &v1, const float &num);
//
//std::vector<float> hazard(const std::vector<float> &r, const float &lambda);
//
//std::vector<float> studentpdf(const float &x, const std::vector<float> &mu, const std::vector<float> &var, const std::vector<float> &alpha);
//
//void print_matrix(const std::vector<std::vector<float>> &matrix);
//
//std::vector<float> select_a(const std::vector<std::vector<float>> &matrix, int ls, int le, int r);
//
//float sumvec(const std::vector<float> &v1);
//
//float t_kappa(const std::vector<float> &kappa,const int &t);
//
//float t_alpha(const std::vector<float> &alpha,const int &t);
//
//std::vector<float> cal_mu(float x, const std::vector<float> &v1,const std::vector<float> &v2);
//
//std::vector<float> cal_beta(float x, const std::vector<float> &v1,const std::vector<float> &v2,const std::vector<float> &v3);
//
//std::vector<float> cal_var(const std::vector<float> &v1,const std::vector<float> &v2,const std::vector<float> &v3);
//
//int max_index(const std::vector<float> &v);
//
//bool detection(bool initialization, float datapoint,int t);
//
//
//#ifdef __cplusplus
//}
//#endif
//
//#endif /* APPLICATION_USER_TEST_H_ */
