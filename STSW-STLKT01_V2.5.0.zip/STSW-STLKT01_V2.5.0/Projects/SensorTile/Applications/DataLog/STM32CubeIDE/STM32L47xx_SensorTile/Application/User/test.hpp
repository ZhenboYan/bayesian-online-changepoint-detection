/*
 * test.hpp
 *
 *  Created on: May 6, 2022
 *      Author: user
 */
#ifndef APPLICATION_USER_TEST_HPP_
#define APPLICATION_USER_TEST_HPP_

#ifdef __cplusplus
extern "C" {
#endif


//int junk(int input);

void initialize_vectors(int len, float lambda);
bool detection(float datapoint,int tt);

#ifdef __cplusplus
}
#endif

#endif /* APPLICATION_USER_TEST_HPP_ */
